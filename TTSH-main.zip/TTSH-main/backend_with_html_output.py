
from flask import Flask, request, jsonify
from flask_cors import CORS
import fitz  # PyMuPDF
from PIL import Image
import pytesseract
import openai
from bs4 import BeautifulSoup
import os
import json

app = Flask(__name__)
CORS(app)

# === CONFIGURATION ===
API_KEY = "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"
UPLOADS_DIR = "Your Path Here.../uploads"
TEMPLATE_PATH = "Your Path Here.../TTSH-main/TTSH Flashcards - Template.html"
OUTPUT_PATH = "Your Path Here.../TTSH-main/TTSH Flashcards.html"

client = openai.OpenAI(api_key=API_KEY)

def extract_text_from_scanned_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    ocr_results = []
    for i in range(len(doc)):
        page = doc.load_page(i)
        pix = page.get_pixmap(dpi=300)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        text = pytesseract.image_to_string(img)
        ocr_results.append(text)
    return "\n".join(ocr_results)

def generate_flashcards(text):
    prompt = f"Generate 6 flashcards in JSON format with 'question' and 'answer' keys based on the following text:\n{text[:2000]}"
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=1000,
        temperature=0.7
    )

    return response.choices[0].message.content

def insert_flashcards_into_html(html_template_path, flashcards_json, output_path):
    with open(html_template_path, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f, 'html.parser')
    
    try:
        flashcards = json.loads(flashcards_json)
    except Exception as e:
        raise ValueError(f"Failed to parse GPT output as JSON: {e}")
    
    insertion_point = soup.find(id='insertion-point')
    if insertion_point:
        insertion_point.clear()
        for card in flashcards:
            card_div = soup.new_tag('div', **{"class": "flashcard"})
            q_div = soup.new_tag('div', **{"class": "question"})
            q_div.string = card['question']
            a_div = soup.new_tag('div', **{"class": "answer"})
            a_div.string = card['answer']
            toggle_btn = soup.new_tag('button', **{"class": "btn-preview", "onclick": "toggleAnswer(this)"})
            toggle_btn.string = "Show Answer"
            card_div.extend([q_div, a_div, toggle_btn])
            insertion_point.append(card_div)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(str(soup.prettify()))

@app.route('/run-script', methods=['POST'])
def run_script():
    data = request.get_json()
    filename = data.get("filename")
    if not filename or not filename.lower().endswith(".pdf"):
        return jsonify({"error": "Invalid or missing filename"}), 400

    pdf_path = os.path.join(UPLOADS_DIR, filename)
    if not os.path.exists(pdf_path):
        return jsonify({"error": "File not found"}), 404

    try:
        extracted_text = extract_text_from_scanned_pdf(pdf_path)
        flashcards_json = generate_flashcards(extracted_text)
        insert_flashcards_into_html(TEMPLATE_PATH, flashcards_json, OUTPUT_PATH)
        return jsonify({"message": "Flashcards generated and saved successfully."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
