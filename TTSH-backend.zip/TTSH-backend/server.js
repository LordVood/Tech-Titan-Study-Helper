const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Define the upload directory
const UPLOAD_DIR = path.join(__dirname, 'uploads');

// Ensure uploads directory exists
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR);
}

// Middleware
app.use(express.static(path.join(__dirname, '../TTSH-main')));
app.use(bodyParser.json());

// Set up file upload handling
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// === ROUTES ===

// Handle file uploads
app.post('/upload', upload.single('filename'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }
  res.redirect('/TTSH%20Upload.html');
});

app.get('/list-pdfs', (req, res) => {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) {
      console.error("Error reading uploads:", err);
      return res.status(500).json({ error: 'Could not list files' });
    }
    const pdfs = files.filter(file => file.toLowerCase().endsWith('.pdf'));
    res.json(pdfs);
  });
});

// Simulated flashcard generation endpoint
app.post('/generate-flashcards', (req, res) => {
  const { filename } = req.body;
  if (!filename || !filename.endsWith('.pdf')) {
    return res.status(400).json({ error: 'Invalid filename' });
  }

  res.json({ flashcards });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
